/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Partida.h
 * Author: enzoq
 *
 * Created on August 3, 2018, 11:15 AM
 */

#ifndef PARTIDA_H
#define PARTIDA_H

#include "ListaJugadores.h"
#include "ListaRecords.h"
#include "Mazo.h"

#include <iostream>
using namespace std;

class Partida {
public:
    Partida();
    Partida(const Partida& orig);
    virtual ~Partida();

    Mazo getMazo();
    void setMazo(Mazo);
    ListaJugadores getJugadores();
    void setJugadores(Jugador);
    ListaRecords getRecords();
    void setRecords(string, int);
private:
    Mazo mazo;
    ListaRecords records;
    ListaJugadores listaJugadores;

};

#endif /* PARTIDA_H */

