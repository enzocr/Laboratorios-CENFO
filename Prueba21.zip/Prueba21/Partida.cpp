/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Partida.cpp
 * Author: enzoq
 * 
 * Created on August 3, 2018, 11:15 AM
 */

#include "Partida.h"
#include <iostream>
using namespace std;

Partida::Partida() {

}

Partida::Partida(const Partida& orig) {
}

Partida::~Partida() {
}

Mazo Partida::getMazo() {
    return mazo;
}

void Partida::setMazo(Mazo pMazo) {
    mazo = pMazo;
}

ListaJugadores Partida::getJugadores() {
    return listaJugadores;
}

void Partida::setJugadores(Jugador pJugador) {
    getJugadores().insertarOrdenado(pJugador);
}

ListaRecords Partida::getRecords() {
    return records;
}

void Partida::setRecords(string pNombre, int pApuesta) {

}
