/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   ListaRecords.cpp
 * Author: enzoq
 * 
 * Created on August 3, 2018, 11:19 AM
 */

#include "ListaRecords.h"

ListaRecords::ListaRecords() {
}

ListaRecords::ListaRecords(const ListaRecords& orig) {
}

ListaRecords::~ListaRecords() {
}

