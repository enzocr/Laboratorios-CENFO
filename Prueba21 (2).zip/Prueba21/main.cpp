/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   main.cpp
 * Author: enzoq
 *
 * Created on August 3, 2018, 9:06 AM
 */

#include <cstdlib>
#include <iostream>
#include "Mazo.h"
#include "Gestor.h"
#include "Partida.h"

using namespace std;
//Gestor gestor;
Mazo mazo;

/*
 * 
 */
int main(int argc, char** argv) {


    int cantJugadores;
    cout << "Cuantos jugadores van a jugar: ";
    cin>>cantJugadores;
    string nombre;
    int apuesta, cedula;

    for (int i = 0; i < 2; i++) {
        
        for (int j = 0; j < cantJugadores; j++) {
            cout << "Carta repartida a JUGADOR #" << j + 1 << ": " << mazo.desapilar().toString() << "\n";
        }
        cout << "Carta repartida a DEALER: " << mazo.desapilar().toString() << "\n";
    
    }


//        for (int i = 0; i < cantJugadores; i++) {
//    
//            cout << "Cedula de  jugador #" << i + 1 << ": ";
//            cin>>cedula;
//            cout << "Nombre de jugador #" << i + 1 << ": ";
//            cin>>nombre;
//            cout << "Apuesta de jugador #" << i + 1 << ": ";
//            cin>>apuesta;
//            Jugador jugador(cedula, nombre, apuesta);
//    
//    
//            gestor.getPartida().getJugadores().insertarOrdenado(jugador);
//    
//            jugador.setCarta(gestor.getPartida().getMazo().desapilar());
//            jugador.setCarta(gestor.getPartida().getMazo().desapilar());
//    
//            //cout << jugador.toString();
//            cout << "\n";
//        }





    return 0;
}

