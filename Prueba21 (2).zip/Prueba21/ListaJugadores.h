/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   ListaJugadores.h
 * Author: enzoq
 *
 * Created on August 3, 2018, 11:45 AM
 */

#ifndef LISTAJUGADORES_H
#define LISTAJUGADORES_H
#include "NodoJugador.h"
#include "Jugador.h"
using namespace std;

class ListaJugadores {
public:
    ListaJugadores();
    ListaJugadores(const ListaJugadores& orig);
    virtual ~ListaJugadores();

    bool isNull();
    void insertarInicio(Jugador);
    void insertarOrdenado(Jugador);
    NodoJugador* buscarPorCedula(int);
    NodoJugador* buscarPorNombre(string);
    bool eliminarJugador(int);
    std::string mostrarLista();
    NodoJugador* getCabeza();
    void setCabeza(NodoJugador*);
private:
    NodoJugador* cabeza;
};

#endif /* LISTAJUGADORES_H */

