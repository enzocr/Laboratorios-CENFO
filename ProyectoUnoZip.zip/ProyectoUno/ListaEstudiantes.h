/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   ListaEstudiantes.h
 * Author: enzoq
 *
 * Created on July 11, 2018, 5:47 PM
 */

#ifndef LISTAESTUDIANTES_H
#define LISTAESTUDIANTES_H
//#include "Estudiante.h"
#include"NodoEstudiante.h"

class ListaEstudiantes {
public:
    ListaEstudiantes();
    virtual ~ListaEstudiantes();
    bool isNull();
    void insertarInicio(NodoEstudiante*);
    void insertarOrdenado(NodoEstudiante*);
    NodoEstudiante* buscarPorCedula(int);
    bool eliminarNodoEstudiante(int);
    std::string mostrarLista();
    NodoEstudiante* getCabeza();
    void setCabeza(NodoEstudiante*);
private:
    NodoEstudiante* cabeza;

};

#endif /* LISTAESTUDIANTES_H */

