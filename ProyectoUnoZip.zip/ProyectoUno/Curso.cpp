/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Curso.cpp
 * Author: enzoq
 * 
 * Created on July 11, 2018, 5:47 PM
 */

#include "Curso.h"
#include "Estudiante.h"
#include "NodoEstudiante.h"
#include "ListaEstudiantes.h"
#include "Aula.h"
#include "ListaAulas.h"

#include <sstream>
#include <iostream>
using namespace std;

Curso::Curso() {
    setCodigo(0);
    setNombre(" ");
    setHorario(" ");
    setDia(" ");

     listaEstudiantes.setCabeza(NULL);
    
}

Curso::Curso(int pCodigo, string pNombre, string pHorario, string pDia, Aula pAula) {
    setCodigo(pCodigo);
    setNombre(pNombre);
    setHorario(pHorario);
    setDia(pDia);
    setAula(pAula);
    listaEstudiantes.setCabeza(NULL);
}

Curso::~Curso() {
}

int Curso::getCodigo() {
    return codigo;
}

void Curso::setCodigo(int pCodigo) {
    codigo = pCodigo;
}

string Curso::getNombre() {
    return nombre;
}

void Curso::setNombre(string pNombre) {
    nombre = pNombre;
}

Aula Curso::getAula() {
    return aula;
}

void Curso::setAula(Aula pAula) {
    aula = pAula;
}

string Curso::getHorario() {
    return horario;
}

void Curso::setHorario(string pHorario) {
    horario = pHorario;
}

string Curso::getDia() {
    return dia;
}

void Curso::setDia(string pDia) {
    dia = pDia;
}

ListaEstudiantes Curso::getListaEstudiantes() {
    return listaEstudiantes;
}

string Curso::toString() {
    std::ostringstream s;
    s << getCodigo() << ", " << getNombre() << ", " << getAula().getNumero() << ", " << getHorario() << ", " << getDia() << "\n";
    s << listaEstudiantes.mostrarLista();
    return s.str();
}

void Curso::matricularEstudiante(NodoEstudiante* estudiante) {
    listaEstudiantes.insertarOrdenado(estudiante);
}

string Curso::mostrarEstudiantesMatriculados() {
    std::ostringstream s;
    s << listaEstudiantes.mostrarLista();
    return s.str();
}

bool Curso::eliminarEstudiante(int pCedula) {
    return listaEstudiantes.eliminarNodoEstudiante(pCedula);
}