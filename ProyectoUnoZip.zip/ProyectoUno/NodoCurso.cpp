/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   NodoCurso.cpp
 * Author: enzoq
 * 
 * Created on July 11, 2018, 5:50 PM
 */

#include "NodoCurso.h"

NodoCurso::NodoCurso() {

}

NodoCurso::NodoCurso(Curso pCurso) {
    setCurso(pCurso);
}

NodoCurso::~NodoCurso() {
}

Curso NodoCurso::getCurso() {
    return curso;
}

void NodoCurso::setCurso(Curso pCurso) {
    curso = pCurso;
}

NodoCurso* NodoCurso::getSiguiente() {
    return siguiente;
}

void NodoCurso::setSiguiente(NodoCurso* pSiguiente) {
    siguiente = pSiguiente;
}

