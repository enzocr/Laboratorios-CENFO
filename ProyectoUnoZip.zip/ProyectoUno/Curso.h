/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Curso.h
 * Author: enzoq
 *
 * Created on July 11, 2018, 5:47 PM
 */

#ifndef CURSO_H
#define CURSO_H
#include "ListaEstudiantes.h"
#include "Estudiante.h"
#include "Aula.h"
#include <sstream>
#include <iostream>
using namespace std;

class Curso {
public:
    Curso();
    Curso(int, string, string, string, Aula);
    virtual ~Curso();
    int getCodigo();
    void setCodigo(int);
    string getNombre();
    void setNombre(string);
    Aula getAula();
    void setAula(Aula);
    string getHorario();
    void setHorario(string);
    string getDia();
    void setDia(string);
    string toString();
    void matricularEstudiante(NodoEstudiante*);
    std::string mostrarEstudiantesMatriculados();
    bool eliminarEstudiante(int);
    ListaEstudiantes getListaEstudiantes();

private:
    int codigo;
    string nombre;
    Aula aula;
    ListaEstudiantes listaEstudiantes;
    string horario;
    string dia;

};

#endif /* CURSO_H */

