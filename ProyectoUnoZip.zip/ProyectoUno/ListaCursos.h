/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   ListaCursos.h
 * Author: enzoq
 *
 * Created on July 11, 2018, 5:46 PM
 */

#ifndef LISTACURSOS_H
#define LISTACURSOS_H
#include "Curso.h"
#include "NodoCurso.h"
class ListaCursos {
public:
    ListaCursos();
    virtual ~ListaCursos();
    bool isNull();
    void insertarInicio(Curso);
    void insertarOrdenado(Curso);
    NodoCurso* buscarPorCodigo(int);
    bool eliminarNodoCurso(int);
    std::string mostrarLista();
    NodoCurso* getCabeza();
    void setCabeza(NodoCurso*);
//    ListaCursos getListaCursos();
    
private:
    NodoCurso* cabeza;
};

#endif /* LISTACURSOS_H */

