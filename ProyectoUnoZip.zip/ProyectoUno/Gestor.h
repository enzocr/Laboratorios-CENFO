/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Gestor.h
 * Author: enzoq
 *
 * Created on July 12, 2018, 4:31 PM
 */

#ifndef GESTOR_H
#define GESTOR_H

#include "ListaCursos.h"
#include "ListaEstudiantes.h"
#include "ListaGeneralEstudiantes.h"
#include "ListaAulas.h"

using namespace std;

class Gestor {
public:
    Gestor();
    virtual ~Gestor();
    Gestor(const Gestor& orig);
    void crearCurso(int, string, string, string, Aula);
    std::string verCursosDisponibles();
    bool eliminarNodoCurso(int);
    void matricularEstudianteACurso(NodoEstudiante*, NodoCurso*);
    bool eliminarNodoEstudianteDeCurso(int);
    std::string verEstudiantesPorCurso(int);
    NodoCurso* buscarCursoPorCodigo(int);
    string buscarEstudiantePorCedulaEnCurso(int);
    void agregarEstudianteNuevo(int, string, string, string, string, double);
    NodoEstudiante* buscarEstudiante(int);
    string calcularEstado(double);
    Aula asignarAula();
    bool listaCursosIsEmpty();
private:
    ListaCursos listaCursos;
    ListaEstudiantes listaEstudiantes;
    ListaGeneralEstudiantes listaGeneral;
    ListaAulas listaAulas;
};

#endif /* GESTOR_H */

