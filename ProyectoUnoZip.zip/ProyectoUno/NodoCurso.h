/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   NodoCurso.h
 * Author: enzoq
 *
 * Created on July 11, 2018, 5:50 PM
 */

#ifndef NODOCURSO_H
#define NODOCURSO_H
#include "Curso.h"
class NodoCurso {
public:
    NodoCurso();
    NodoCurso(Curso);
    virtual ~NodoCurso();
    Curso getCurso();
    void setCurso(Curso);
    NodoCurso* getSiguiente();
    void setSiguiente(NodoCurso*);
private:
    Curso curso;
    NodoCurso* siguiente;

};

#endif /* NODOCURSO_H */

