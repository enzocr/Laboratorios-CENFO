/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Estudiante.h
 * Author: enzoq
 *
 * Created on July 11, 2018, 5:48 PM
 */

#ifndef ESTUDIANTE_H
#define ESTUDIANTE_H

#include <sstream>
#include <iostream>
using namespace std;

class Estudiante {
public:
    Estudiante();
    Estudiante(int, string, string, string, string, double, string);
    virtual ~Estudiante();

    int getCedula();
    void setCedula(int);
    string getPrimerNombre();
    void setPrimerNombre(string);
    string getSegundoNombre();
    void setSegundoNombre(string);
    string getPrimerApellido();
    void setPrimerApellido(string);
    string getSegundoApellido();
    void setSegundoApellido(string);
    double getNotaFinal();
    void setNotaFinal(double);
    string getEstado();
    void setEstado(string);
    string toString();
private:
    int cedula;
    string primerNombre;
    string segundoNombre;
    string primerApellido;
    string segundoApellido;
    double notaFinal;
    string estado;
};

#endif /* ESTUDIANTE_H */

