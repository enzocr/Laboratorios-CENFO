/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   ListaAulas.cpp
 * Author: enzoq
 * 
 * Created on July 18, 2018, 5:53 PM
 */

#include "ListaAulas.h"
#include "Aula.h"
#include <iostream>
#include <sstream>

using namespace std;

ListaAulas::ListaAulas() {
    aulas[0] = Aula(1, false);
    aulas[1] = Aula(2, false);
    aulas[2] = Aula(3, false);
    aulas[3] = Aula(4, false);
    aulas[4] = Aula(5, false);
}

ListaAulas::~ListaAulas() {
}

Aula* ListaAulas::getAulas() {
    return aulas;
}

void ListaAulas::insertarAula(Aula pAula) {
    aulas[pAula.getNumero()] = pAula;
}

Aula ListaAulas::asignarAula() {
    Aula aux(-1, false);
    if (!aulasLlenas()) {
        for (int i = 0; i < 5; i++) {
            if (!aulas[i].getAsigned()) {
                aux = aulas[i];
                aux.setAsigned(true);
                aulas[i] = aux;
                return aux;
            }
        }
    }
    return aux;

}

bool ListaAulas::aulasLlenas() {
    int cont = 0;
    for (int i = 0; i < 5; i++) {
        if (aulas[i].getAsigned()) {
            cont++;
        }
    }
    if (cont == 5) {
        return true;
    } else {
        return false;
    }
}

bool ListaAulas::borrarAula(int pNumero) {
    if (aulas[pNumero].getAsigned()) {
        aulas[pNumero].setAsigned(false);
        return true;
    } else {
        return false;
    }
}

string ListaAulas::mostrarAulas() {

    std::ostringstream s;

    for (int i = 0; i < 5; i++) {
        if (aulas[i].getAsigned()) {
            s << aulas[i].getNumero() << "\n";
        }
    }

    return s.str();


}