/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Gestor.cpp
 * Author: enzoq
 * 
 * Created on July 12, 2018, 4:31 PM
 */

#include "Gestor.h"
#include "Curso.h"
#include "NodoCurso.h"

Gestor::Gestor() {
}

Gestor::Gestor(const Gestor& orig) {
}

Gestor::~Gestor() {
}
////////////////////////////////CURSOS

void Gestor::crearCurso(int pCodigo, string pNombre, string pHorario, string pDia, Aula pAula) {
    Curso curso(pCodigo, pNombre, pHorario, pDia, pAula);
    listaAulas.insertarAula(pAula);
    listaCursos.insertarOrdenado(curso);
}

bool Gestor::listaCursosIsEmpty() {
    if (listaCursos.isNull()) {
        return true;
    } else {
        return false;
    }
}

NodoCurso* Gestor::buscarCursoPorCodigo(int pCodigo) {
    if (listaCursos.isNull()) {
        return NULL;
    } else {
        return listaCursos.buscarPorCodigo(pCodigo);
    }
}

void Gestor::matricularEstudianteACurso(NodoEstudiante* estudiante, NodoCurso* curso) {

    curso->getCurso().matricularEstudiante(estudiante);
    listaGeneral.insertarOrdenado(estudiante->getEstudiante().getCedula(),
            curso->getCurso().getCodigo());


}

std::string Gestor::verCursosDisponibles() {
    if (listaCursos.isNull()) {
        return "No hay cursos registrados";
    } else {
        return listaCursos.mostrarLista();
    }
}

bool Gestor::eliminarNodoCurso(int pCodigo) {
    if (listaCursos.isNull()) {
        return false;
    } else {
        return listaCursos.eliminarNodoCurso(pCodigo);
    }
}

string Gestor::buscarEstudiantePorCedulaEnCurso(int pCedula) {
    std::ostringstream s;
    if (listaGeneral.buscarPorEstudiante(pCedula) != NULL) {
        NodoEstudiante* estudiante = listaEstudiantes.buscarPorCedula(pCedula);
        s << estudiante->getEstudiante().toString();
        s << "*******cursos*******";
        if (!listaCursos.ListaCursos::isNull()) {
            NodoCurso* aux = listaCursos.getCabeza();
            while (aux != NULL) {
                if (!aux->getCurso().getListaEstudiantes().isNull()) {
                    NodoEstudiante* est = aux->getCurso().getListaEstudiantes().getCabeza();
                    while (est != NULL) {
                        if (est->getEstudiante().getCedula() == pCedula) {
                            s << aux->getCurso().toString();
                        } else {
                            est = est->getSiguiente();
                            est->setSiguiente(aux->getCurso().getListaEstudiantes().getCabeza());
                        }
                    }
                } else {
                    aux = aux ->getSiguiente();
                    aux->setSiguiente(listaCursos.getCabeza());
                }
            }
        } else {
            return NULL;
        }
        return s.str();
    } else {
        cout << "Estudiante no encontrado";
    }

}

std::string Gestor::verEstudiantesPorCurso(int pCodigoCurso) {
    if (listaCursos.isNull()) {
        return "No hay cursos registrados\n";
    } else {
        if (listaCursos.buscarPorCodigo(pCodigoCurso)->getCurso().getListaEstudiantes().isNull()) {
            return "No hay estudiantes registrados\n";
        } else {
            return listaCursos.buscarPorCodigo(pCodigoCurso)->getCurso().mostrarEstudiantesMatriculados();
        }
    }
}
//////////////////////////////////CURSOS


//////////////////////////////////ESTUDIANTES

void Gestor::agregarEstudianteNuevo(int pCedula, string pPrimerNombre, string pSegundoNombre, string pPrimerApellido,
        string pSegundoApellido, double pNotaFinal) {
    Estudiante estudiante(pCedula, pPrimerNombre, pSegundoNombre,
            pPrimerApellido, pSegundoApellido, pNotaFinal, calcularEstado(pNotaFinal));
    NodoEstudiante* est = new NodoEstudiante(estudiante);
    listaEstudiantes.insertarOrdenado(est);

}

bool Gestor::eliminarNodoEstudianteDeCurso(int pCedula) {

}

NodoEstudiante* Gestor::buscarEstudiante(int pCedula) {
    if (listaEstudiantes.isNull()) {
        return NULL;
    } else {
        return listaEstudiantes.buscarPorCedula(pCedula);
    }
}

//////////////////////////////////ESTUDIANTES


///////////////////////////////////OTROS

Aula Gestor::asignarAula() {

    Aula aula = listaAulas.asignarAula();
    return aula;
}

string Gestor::calcularEstado(double pNotaFinal) {
    if (pNotaFinal > 70.0) {
        return "APROBADO";
    } else if (pNotaFinal < 60.0) {
        return "REPROBADO";
    } else {
        return "APLAZADO";
    }
}
///////////////////////////////////OTROS

