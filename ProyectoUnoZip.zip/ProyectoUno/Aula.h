/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Aula.h
 * Author: enzoq
 *
 * Created on July 18, 2018, 5:56 PM
 */

#ifndef AULA_H
#define AULA_H

class Aula {
public:
    Aula();
    Aula(int, bool);
    virtual ~Aula();
    int getNumero();
    void setNumero(int);
    bool getAsigned();
    void setAsigned(bool);
private:
    int numero;
    bool isAsigned;
};

#endif /* AULA_H */

