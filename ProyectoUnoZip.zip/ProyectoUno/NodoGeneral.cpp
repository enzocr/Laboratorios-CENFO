/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   NodoGeneral.cpp
 * Author: enzoq
 * 
 * Created on July 11, 2018, 6:05 PM
 */

#include "NodoGeneral.h"

NodoGeneral::NodoGeneral() {
    setCedulaEstudiante(0);
    setCodigoCurso(0);
}

NodoGeneral::NodoGeneral(int pCedulaEstudiante, int pCodigoCurso) {
    setCedulaEstudiante(pCedulaEstudiante);
    setCodigoCurso(pCodigoCurso);
}

NodoGeneral::~NodoGeneral() {
}

int NodoGeneral::getCedulaEstudiante() {
    return cedulaEstudiante;
}

void NodoGeneral::setCedulaEstudiante(int pCedulaEstudiante) {
    cedulaEstudiante = pCedulaEstudiante;
}

int NodoGeneral::getCodigoCurso() {
    return codigoCurso;
}

void NodoGeneral::setCodigoCurso(int pCodigoCurso) {
    codigoCurso = pCodigoCurso;
}

NodoGeneral* NodoGeneral::getSiguiente() {
    return siguiente;
}

void NodoGeneral::setSiguiente(NodoGeneral* pSiguiente) {
    siguiente = pSiguiente;
}