/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   ListaCursos.cpp
 * Author: enzoq
 * 
 * Created on July 11, 2018, 5:46 PM
 */
#include <sstream>
#include <iostream>
#include "ListaCursos.h"
#include "NodoCurso.h"
#include "Curso.h"
using namespace std;

ListaCursos::ListaCursos() {
    setCabeza(NULL);
}

ListaCursos::~ListaCursos() {
}

//ListaCursos::getListaCursos() {
//    return this;
//}

NodoCurso* ListaCursos::getCabeza() {
    return cabeza;
}

void ListaCursos::setCabeza(NodoCurso* pCabeza) {
    cabeza = pCabeza;
}

bool ListaCursos::isNull() {
    return getCabeza() == NULL;
}

void ListaCursos::insertarInicio(Curso pCurso) {
    NodoCurso* nuevo = new NodoCurso(pCurso);
    nuevo->setSiguiente(getCabeza());
    setCabeza(nuevo);
}

void ListaCursos::insertarOrdenado(Curso pCurso) {

    NodoCurso* nuevo = new NodoCurso(pCurso);

    if (isNull()) {
        insertarInicio(pCurso);
    } else {
        if (getCabeza()->getCurso().getCodigo() > nuevo->getCurso().getCodigo()) {
            insertarInicio(pCurso);
        } else {
            NodoCurso* aux = getCabeza();
            while (aux->getSiguiente() != NULL && aux->getSiguiente()->getCurso().getCodigo() < pCurso.getCodigo()) {
                aux = aux->getSiguiente();
            }
            nuevo->setSiguiente(aux->getSiguiente());
            aux->setSiguiente(nuevo);
        }
    }
}

NodoCurso* ListaCursos::buscarPorCodigo(int pCodigo) {

    if (!isNull()) {
        NodoCurso* aux = getCabeza();
        while (aux != NULL) {
            if (aux -> getCurso().getCodigo() == pCodigo) {
                return aux;
            } else {
                aux = aux ->getSiguiente();
                aux ->setSiguiente(getCabeza());
            }
        }
    } else {
        return NULL;
    }

}

string ListaCursos::mostrarLista() {

    std::ostringstream s;
    if (!isNull()) {
        NodoCurso* aux = getCabeza();
        while (aux != NULL) {

            s << aux->getCurso().toString() << "\n";
            aux = aux ->getSiguiente();
        }
    }
    return s.str();


}

bool ListaCursos::eliminarNodoCurso(int pCodigo) {
    if (isNull()) {
        return false;
    } else {
        if (getCabeza()->getCurso().getCodigo() == pCodigo) {
            setCabeza(getCabeza()->getSiguiente());
            return true;
        } else {
            NodoCurso* temp = getCabeza();
            while (temp != NULL) {
                temp = temp->getSiguiente();
                if (temp != NULL) {
                    temp = temp->getSiguiente()->getSiguiente();
                    return true;
                } else {
                    return false;
                }
            }
        }
    }
}