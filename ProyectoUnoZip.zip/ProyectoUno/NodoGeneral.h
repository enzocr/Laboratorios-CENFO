/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   NodoGeneral.h
 * Author: enzoq
 *
 * Created on July 11, 2018, 6:05 PM
 */

#ifndef NODOGENERAL_H
#define NODOGENERAL_H

class NodoGeneral {
public:
    NodoGeneral();
    NodoGeneral(int, int);
    virtual ~NodoGeneral();
    int getCedulaEstudiante();
    void setCedulaEstudiante(int);
    int getCodigoCurso();
    void setCodigoCurso(int);
    NodoGeneral* getSiguiente();
    void setSiguiente(NodoGeneral*);
private:
    int cedulaEstudiante;
    int codigoCurso;
    NodoGeneral* siguiente;

};

#endif /* NODOGENERAL_H */

