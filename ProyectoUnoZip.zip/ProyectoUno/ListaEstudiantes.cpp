/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   ListaEstudiantes.cpp
 * Author: enzoq
 * 
 * Created on July 11, 2018, 5:47 PM
 */
#include <sstream>
#include <iostream>
#include "ListaEstudiantes.h"
#include "NodoEstudiante.h"
#include "Estudiante.h"
using namespace std;

ListaEstudiantes::ListaEstudiantes() {
    setCabeza(NULL);
}

ListaEstudiantes::~ListaEstudiantes() {
}

NodoEstudiante* ListaEstudiantes::getCabeza() {
    return cabeza;
}

void ListaEstudiantes::setCabeza(NodoEstudiante* pCabeza) {
    cabeza = pCabeza;
}

bool ListaEstudiantes::isNull() {
    return getCabeza() == NULL;
}

void ListaEstudiantes::insertarInicio(NodoEstudiante* nuevo) {
    //NodoEstudiante* nuevo = new NodoEstudiante(pEstudiante);

    nuevo->setSiguiente(getCabeza());

    setCabeza(nuevo);

}

void ListaEstudiantes::insertarOrdenado(NodoEstudiante* nuevo) {

    // NodoEstudiante* nuevo = new NodoEstudiante(pEstudiante);

    if (isNull()) {
        insertarInicio(nuevo);
    } else {

        if (getCabeza()->getEstudiante().getCedula() > nuevo->getEstudiante().getCedula()) {
            insertarInicio(nuevo);
        } else {
            NodoEstudiante* aux = getCabeza();
            while (aux->getSiguiente() != NULL && aux->getSiguiente()->getEstudiante().getCedula() <
                    nuevo->getEstudiante().getCedula()) {
                aux = aux->getSiguiente();
            }
            nuevo->setSiguiente(aux->getSiguiente());
            aux->setSiguiente(nuevo);
        }
    }
}

NodoEstudiante* ListaEstudiantes::buscarPorCedula(int pCedula) {

    if (!isNull()) {
        NodoEstudiante* aux = getCabeza();
        while (aux != NULL) {
            if (aux -> getEstudiante().getCedula() == pCedula) {
                return aux;
            } else {
                aux = aux ->getSiguiente();
                aux ->setSiguiente(getCabeza());
            }
        }
    } else {
        return NULL;
    }

}

string ListaEstudiantes::mostrarLista() {

    std::ostringstream s;
    if (!isNull()) {
        NodoEstudiante* aux = getCabeza();
        while (aux != NULL) {

            s << aux->getEstudiante().toString() << "\n";
            aux = aux ->getSiguiente();

        }
    } else {
        s << "No hay estudiantes registrados\n";
    }
    return s.str();


}

bool ListaEstudiantes::eliminarNodoEstudiante(int pCedula) {
    if (isNull()) {
        return false;
    } else {
        if (getCabeza()->getEstudiante().getCedula() == pCedula) {
            setCabeza(getCabeza()->getSiguiente());
            return true;
        } else {
            NodoEstudiante* temp = getCabeza();
            while (temp != NULL) {
                temp = temp->getSiguiente();
                if (temp != NULL) {
                    temp = temp->getSiguiente()->getSiguiente();
                    return true;
                } else {
                    return false;
                }
            }
        }
    }
}