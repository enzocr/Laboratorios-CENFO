/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Aula.cpp
 * Author: enzoq
 * 
 * Created on July 18, 2018, 5:57 PM
 */

#include "Aula.h"

Aula::Aula() {
}

Aula::Aula(int pNumero, bool b) {
    numero = pNumero;
    isAsigned = b;
}

Aula::~Aula() {
}

int Aula::getNumero() {
    return numero;
}

void Aula::setNumero(int pNumero) {
    numero = pNumero;
}

bool Aula::getAsigned() {
    return isAsigned;
}

void Aula::setAsigned(bool t) {
    isAsigned = t;
}