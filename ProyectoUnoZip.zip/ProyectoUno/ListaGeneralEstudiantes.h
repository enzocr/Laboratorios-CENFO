/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   ListaGeneralEstudiantes.h
 * Author: enzoq
 *
 * Created on July 11, 2018, 6:04 PM
 */

#ifndef LISTAGENERALESTUDIANTES_H
#define LISTAGENERALESTUDIANTES_H
#include "NodoGeneral.h"
#include "NodoEstudiante.h"
#include "NodoCurso.h"
class ListaGeneralEstudiantes {
public:
    ListaGeneralEstudiantes();
    virtual ~ListaGeneralEstudiantes();
    bool isNull();
    void insertarInicio(int, int);
    void insertarOrdenado(int, int);
    NodoGeneral* buscarPorCurso(int);
    NodoGeneral* buscarPorEstudiante(int);
    bool eliminarNodoCurso(int);
    bool eliminarNodoEstudiante(int);
    std::string mostrarLista();
    NodoGeneral* getCabeza();
    void setCabeza(NodoGeneral*);
private:
    NodoGeneral* cabeza;
};

#endif /* LISTAGENERALESTUDIANTES_H */

