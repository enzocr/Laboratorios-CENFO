/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   ListaAulas.h
 * Author: enzoq
 *
 * Created on July 18, 2018, 5:53 PM
 */

#ifndef LISTAAULAS_H
#define LISTAAULAS_H
#include"Aula.h"

#include <sstream>
#include <iostream>

class ListaAulas {
public:
    ListaAulas();
    virtual ~ListaAulas();
    Aula* getAulas();
    void insertarAula(Aula);
    Aula asignarAula();
    bool aulasLlenas();
    bool borrarAula(int);
    std::string mostrarAulas();
private:
    Aula aulas[5];

};

#endif /* LISTAAULAS_H */

