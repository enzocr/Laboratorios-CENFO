/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   NodoEstudiante.h
 * Author: enzoq
 *
 * Created on July 11, 2018, 5:50 PM
 */

#ifndef NODOESTUDIANTE_H
#define NODOESTUDIANTE_H
#include "Estudiante.h"
class NodoEstudiante {
public:
    NodoEstudiante();
    NodoEstudiante(Estudiante);
    virtual ~NodoEstudiante();
    Estudiante getEstudiante();
    void setEstudiante(Estudiante);
    NodoEstudiante* getSiguiente();
    void setSiguiente(NodoEstudiante*);
private:
    Estudiante estudiante;
    NodoEstudiante* siguiente;
};

#endif /* NODOESTUDIANTE_H */

