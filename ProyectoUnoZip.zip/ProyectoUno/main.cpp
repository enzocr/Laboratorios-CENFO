/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   main.cpp
 * Author: enzoq
 *
 * Created on July 11, 2018, 5:46 PM
 */
#include <iostream>
#include <cstdlib>

#include "Gestor.h"

using namespace std;
Gestor gestor;
void mostrarMenu();
int leerOpcion();
void ejecutarAccion(int);

void crearCurso();
void verCursosDisponibles();
void cursosMatriculadosPorEstudiante();
void eliminarCurso();
void agregarEstudianteNuevo();
void matricularEstudiante();
void eliminarEstudianteDeCurso();
void verEstudiantesPorCurso();
void matricularEstudianteACurso(NodoEstudiante*);
bool puedeMatricularEstudiante();

/*
 * 
 */
int main(int argc, char** argv) {
    int opc;
    do {
        mostrarMenu();
        opc = leerOpcion();
        ejecutarAccion(opc);

    } while (opc != 9);

    return 0;
}

void mostrarMenu() {
    cout << "\n";
    cout << "1. ---|           CREAR CURSO              |--- \n";
    cout << "2. ---|      VER CURSOS DISPONIBLES        |--- \n";
    cout << "3. ---| CURSOS MATRICULADOS POR ESTUDIANTE |--- \n";
    cout << "4. ---|         ELIMINAR CURSO             |--- \n";
    cout << "5. ---|      AÑADIR ESTUDIANTE NUEVO       |--- \n";
    cout << "6. ---|   MATRICULAR ESTUDIANTE A CURSO    |--- \n";
    cout << "7. ---|    ELIMINAR ESTUDIANTE DE CURSO    |--- \n";
    cout << "8. ---|     VER ESTUDIANTES POR CURSO      |--- \n";
    cout << "9. ---|              SALIR                 |--- \n";
}

int leerOpcion() {

    int opcion;


    cout << "Seleccione accion a realizar: ";
    cin>>opcion;


    return opcion;
}

void ejecutarAccion(int pOpcion) {

    switch (pOpcion) {

        case 1:
            crearCurso();
            break;

        case 2:
            verCursosDisponibles();
            break;

        case 3:
            cursosMatriculadosPorEstudiante();//*****
            break;

        case 4:
            eliminarCurso();
            break;

        case 5:
            agregarEstudianteNuevo();
            break;

        case 6:
            matricularEstudiante();//*****
            break;

        case 7:
            eliminarEstudianteDeCurso();
            break;

        case 8:
            verEstudiantesPorCurso();//*****
            break;

        case 9:
            cout << "GRACIAS POR USAR EL SISTEMA";
            break;

        default:
            cout << "OPCION INVALIDA";

    }
}

void crearCurso() {
    int codigo;
    Aula aula;
    string nombre, horario, dia;

    cout << "Codigo del curso: ";
    cin>>codigo;
    NodoCurso* curso = gestor.buscarCursoPorCodigo(codigo);
    if (curso != NULL) {
        cout << "Curso ya existe con el codigo: " << codigo;
    } else {
        cout << "Nombre del curso: ";
        cin>>nombre;
        cout << "Horario del curso: ";
        cin >> horario;
        cout << "Dia del curso: ";
        cin >> dia;
        aula = gestor.asignarAula();
        if (aula.getNumero() == -1) {
            cout << "No hay mas aulas disponibles";
        } else {

            gestor.crearCurso(codigo, nombre, horario, dia, aula);

        }
    }

}

void verCursosDisponibles() {
    cout << gestor.verCursosDisponibles();
}

void cursosMatriculadosPorEstudiante() {
    int cedula;
    cout << "Cedula: ";
    cin>>cedula;
    NodoEstudiante* est = gestor.buscarEstudiante(cedula);
    if (est != NULL) {
        cout << gestor.buscarEstudiantePorCedulaEnCurso(cedula);
    } else {
        cout << "Estudiante no encontrado en el sistema";
    }
}

void eliminarCurso() {
    int eliminar;
    cout << "Digite codigo del curso a eliminar";
    cin>>eliminar;

    if (gestor.eliminarNodoCurso(eliminar)) {
        cout << "CURSO ELIMINADO \n";
    } else {
        cout << "EL CURSO NO FUE ELIMINADO O ENCONTRADO \n";
    }
}

void agregarEstudianteNuevo() {

    int cedula;
    string primerNombre;
    string segundoNombre = " ";
    string primerApellido;
    string segundoApellido = " ";
    double notaFinal;

    cout << "Cedula: ";
    cin>>cedula;
    NodoEstudiante* est = gestor.buscarEstudiante(cedula);
    if (est != NULL) {
        cout << "Estudiante ya registrado con cedula: " << cedula;
    } else {

        cout << "Primer nombre: ";
        cin>>primerNombre;
        cout << "Segundo nombre ";
        cin>>segundoNombre;
        cout << "Primer apellido: ";
        cin>>primerApellido;
        cout << "Segundo apellido: ";
        cin>>segundoApellido;
        cout << "Nota final: ";
        cin>>notaFinal;

        gestor.agregarEstudianteNuevo(cedula, primerNombre, segundoNombre, primerApellido, segundoApellido, notaFinal);

        NodoEstudiante* estudiante = gestor.buscarEstudiante(cedula);
        if (estudiante == NULL) {
            cout << "Estudiante no se registró \n";
        } else {
            cout << "Estudiante registrado \n";
        }
        if (!puedeMatricularEstudiante()) {
        } else {

            int decision;
            cout << "Desea matricular al estudiante en algun curso? SI(1) || NO (2)";
            cin>>decision;
            if (decision == 1) {
                matricularEstudianteACurso(estudiante);
            }
        }
    }
}

void matricularEstudiante() {

    if (!puedeMatricularEstudiante()) {
    } else {
        int cedula;
        cout << "Cedula de estudiante a matricular en curso: ";
        cin>>cedula;
        NodoEstudiante* estudiante = gestor.buscarEstudiante(cedula);
        if (estudiante == NULL) {
            cout << "El estudiante no se encuentra en el sistema";
        } else {
            int codigo;
            cout << "Codigo de curso a matricular: ";
            cin>>codigo;

            NodoCurso* curso = gestor.buscarCursoPorCodigo(codigo);
            if (curso == NULL) {
                cout << "CURSO NO EXISTE";
            } else {
                gestor.matricularEstudianteACurso(estudiante, curso);

                cout << gestor.verEstudiantesPorCurso(curso->getCurso().getCodigo());
            }
        }
    }

}

void eliminarEstudianteDeCurso() {

}

void verEstudiantesPorCurso() {
    int codigo;
    cout << "Codigo de curso a ver estudiantes: ";
    cin>>codigo;

    NodoCurso* curso = gestor.buscarCursoPorCodigo(codigo);
    if (curso != NULL) {
        cout << gestor.verEstudiantesPorCurso(codigo);
    } else {
        cout << "Curso no encontrado en el sistema";
    }
}

void matricularEstudianteACurso(NodoEstudiante* estudiante) {
    int codigo;
    cout << "Codigo de curso a matricular: ";
    cin>>codigo;

    NodoCurso* curso = gestor.buscarCursoPorCodigo(codigo);
    if (curso == NULL) {
        cout << "CURSO NO EXISTE";
    } else {
        gestor.matricularEstudianteACurso(estudiante, curso);

        cout << gestor.verEstudiantesPorCurso(curso->getCurso().getCodigo());
    }
}

bool puedeMatricularEstudiante() {
    if (gestor.listaCursosIsEmpty()) {
        cout << "No hay cursos disponibles en el sistema";
        cout << "No puede matricular estudiantes";
        return false;
    } else {
        return true;
    }
}