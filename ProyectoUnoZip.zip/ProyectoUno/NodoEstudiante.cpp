/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   NodoEstudiante.cpp
 * Author: enzoq
 * 
 * Created on July 11, 2018, 5:50 PM
 */

#include "NodoEstudiante.h"

NodoEstudiante::NodoEstudiante() {
}

NodoEstudiante::NodoEstudiante(Estudiante pEstudiante) {
    setEstudiante(pEstudiante);
}

NodoEstudiante::~NodoEstudiante() {
}

Estudiante NodoEstudiante::getEstudiante() {
    return estudiante;
}

void NodoEstudiante::setEstudiante(Estudiante pEstudiante) {
    estudiante = pEstudiante;
}

NodoEstudiante* NodoEstudiante::getSiguiente() {
    return siguiente;
}

void NodoEstudiante::setSiguiente(NodoEstudiante* pSiguiente) {
    siguiente = pSiguiente;
}

