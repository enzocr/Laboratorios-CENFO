
#include "ListaGeneralEstudiantes.h"

ListaGeneralEstudiantes::ListaGeneralEstudiantes() {
    setCabeza(NULL);
}

ListaGeneralEstudiantes::~ListaGeneralEstudiantes() {
}

bool ListaGeneralEstudiantes::isNull() {
    return getCabeza() == NULL;
}

NodoGeneral* ListaGeneralEstudiantes::getCabeza() {
    return cabeza;
}

void ListaGeneralEstudiantes::setCabeza(NodoGeneral* pCabeza) {
    cabeza = pCabeza;
}

void ListaGeneralEstudiantes::insertarInicio(int pCedulaEstudiante, int pCodigoCurso) {
    NodoGeneral* nuevo = new NodoGeneral(pCedulaEstudiante, pCodigoCurso);
    nuevo->setSiguiente(getCabeza());
    setCabeza(nuevo);
}

void ListaGeneralEstudiantes::insertarOrdenado(int pCedulaEstudiante, int pCodigoCurso) {
    NodoGeneral* nuevo = new NodoGeneral(pCedulaEstudiante, pCodigoCurso);

    if (isNull()) {
        insertarInicio(pCedulaEstudiante, pCodigoCurso);
    } else {
        if (getCabeza()->getCedulaEstudiante() > nuevo->getCedulaEstudiante()) {
            insertarInicio(pCedulaEstudiante, pCodigoCurso);
        } else {
            NodoGeneral* aux = getCabeza();
            while (aux->getSiguiente() != NULL && aux->getSiguiente()->getCedulaEstudiante() < pCedulaEstudiante) {
                aux = aux->getSiguiente();
            }
            nuevo->setSiguiente(aux->getSiguiente());
            aux->setSiguiente(nuevo);
        }
    }
}

NodoGeneral* ListaGeneralEstudiantes::buscarPorCurso(int pCodigoCurso) {

    if (!isNull()) {
        NodoGeneral* aux = getCabeza();
        while (aux != NULL) {
            if (aux -> getCodigoCurso() == pCodigoCurso) {
                return aux;
            } else {
                aux = aux ->getSiguiente();
                aux ->setSiguiente(getCabeza());
            }
        }
    } else {
        return NULL;
    }

}

NodoGeneral* ListaGeneralEstudiantes::buscarPorEstudiante(int pCedulaEstudiante) {

    if (!isNull()) {
        NodoGeneral* aux = getCabeza();
        while (aux != NULL) {
            if (aux -> getCedulaEstudiante() == pCedulaEstudiante) {
                return aux;
            } else {
                aux = aux ->getSiguiente();
                aux ->setSiguiente(getCabeza());
            }
        }
    } else {
        return NULL;
    }

}

bool ListaGeneralEstudiantes::eliminarNodoCurso(int pCodigoCurso) {

    if (isNull()) {
        return false;
    } else {
        if (getCabeza()->getCodigoCurso() == pCodigoCurso) {
            setCabeza(getCabeza()->getSiguiente());
            return true;
        } else {
            NodoGeneral* temp = getCabeza();
            while (temp != NULL) {
                temp = temp->getSiguiente();
                if (temp != NULL) {
                    temp = temp->getSiguiente()->getSiguiente();
                    return true;
                } else {
                    return false;
                }
            }
        }
    }
}

bool ListaGeneralEstudiantes::eliminarNodoEstudiante(int pCedulaEstudiante) {

    if (isNull()) {
        return false;
    } else {
        if (getCabeza()->getCedulaEstudiante() == pCedulaEstudiante) {
            setCabeza(getCabeza()->getSiguiente());
            return true;
        } else {
            NodoGeneral* temp = getCabeza();
            while (temp != NULL) {
                temp = temp->getSiguiente();
                if (temp != NULL) {
                    temp = temp->getSiguiente()->getSiguiente();
                    return true;
                } else {
                    return false;
                }
            }
        }
    }

}

std::string ListaGeneralEstudiantes::mostrarLista() {
    //DE MOMENTO NO ES NECESARIA????
    //    std::ostringstream s;
    //    if (!isNull()) {
    //        NodoGeneral* aux = getCabeza();
    //       while (aux != NULL) {
    //            s << aux-> .toString() << "\n";
    //          aux = aux ->getSiguiente();
    //        }
    //   }
    //    return s.str();

}

