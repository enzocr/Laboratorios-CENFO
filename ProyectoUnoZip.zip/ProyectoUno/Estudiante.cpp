/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Estudiante.cpp
 * Author: enzoq
 * 
 * Created on July 11, 2018, 5:48 PM
 */

#include "Estudiante.h"

#include <sstream>
#include <iostream>
using namespace std;

Estudiante::Estudiante() {
    setCedula(0);
    setPrimerNombre(" ");
    setSegundoNombre(" ");
    setPrimerApellido(" ");
    setSegundoApellido(" ");
    setNotaFinal(0.0);
    setEstado(" ");
}

Estudiante::Estudiante(int pCedula, string pPrimerNombre, string pSegundoNombre, string pPrimerApellido,
        string pSegundoApellido, double pNotaFinal, string pEstado) {
    setCedula(pCedula);
    setPrimerNombre(pPrimerNombre);
    setSegundoNombre(pSegundoNombre);
    setPrimerApellido(pPrimerApellido);
    setSegundoApellido(pSegundoApellido);
    setNotaFinal(pNotaFinal);
    setEstado(pEstado);
}

Estudiante::~Estudiante() {
}

int Estudiante::getCedula() {
    return cedula;
}

void Estudiante::setCedula(int pCedula) {
    cedula = pCedula;
}

string Estudiante::getPrimerNombre() {
    return primerNombre;
}

void Estudiante::setPrimerNombre(string pNombre) {
    primerNombre = pNombre;
}

string Estudiante::getSegundoNombre() {
    return segundoNombre;
}

void Estudiante::setSegundoNombre(string pNombre) {
    segundoNombre = pNombre;
}

string Estudiante::getPrimerApellido() {
    return primerApellido;
}

void Estudiante::setPrimerApellido(string pApellido) {
    primerApellido = pApellido;
}

string Estudiante::getSegundoApellido() {
    return segundoApellido;
}

void Estudiante::setSegundoApellido(string pApellido) {
    segundoApellido = pApellido;
}

double Estudiante::getNotaFinal() {
    return notaFinal;
}

void Estudiante::setNotaFinal(double pNotaFinal) {
    notaFinal = pNotaFinal;
}

string Estudiante::getEstado() {
    return estado;
}

void Estudiante::setEstado(string pEstado) {
    estado = pEstado;
}

string Estudiante::toString() {
    std::ostringstream s;
    s << getCedula() << ": " << getPrimerNombre() << " " <<
            getSegundoNombre() << " " << getPrimerApellido() << " " << getSegundoApellido() << "\n";
    s << getNotaFinal() << ": " << getEstado();
    return s.str();
}



